export interface TravelLog {
  id: string;
  title: string;
  content: string;
  imageUrl: string;
  createdAt: string;
}