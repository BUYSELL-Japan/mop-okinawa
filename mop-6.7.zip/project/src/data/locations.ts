export interface Category {
  id: string;
  name: string;
  color: string;
  iconColor: string;
}